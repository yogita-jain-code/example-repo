package db.DTO;

public class ConfigDetailsDTO {

	private Integer configId;
	private String configParam;
	private String configValue;
	
	
	public Integer getConfigId() {
		return configId;
	}
	public void setConfigId(Integer configId) {
		this.configId = configId;
	}
	public String getConfigParam() {
		return configParam;
	}
	public void setConfigParam(String configParam) {
		this.configParam = configParam;
	}
	public String getConfigValue() {
		return configValue;
	}
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}
	
	
	
}
